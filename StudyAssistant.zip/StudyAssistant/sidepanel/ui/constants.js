export const MAX_MODEL_CHARS = 20000;
